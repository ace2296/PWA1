/*
	* Mid Terms for PWA-1
*/
(function () {

var button = document.getElementById("info_btn"); 

var student = {
	name: 'Andre Guerra',
	address: {
		street: '123 Way Street',
		city: 'Bend',
		state: 'OR',
	},
	GPA: [4.0,3.5,3.2],
};

newStudent('Michael Moreno', '123 Bond Street', 'Orlando', 'Florida', [3.2, 4.0, 2.2] )


console.log('Name: ' + student.name);
console.log('Address: ' + student.address.street + ', ' + student.address.city + ' ' + student.address.state);
console.log('GPA: ' + student.GPA);

})();